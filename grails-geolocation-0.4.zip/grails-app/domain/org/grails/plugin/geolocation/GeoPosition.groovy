package org.grails.plugin.geolocation

class GeoPosition {
	Coordinates coords
	long timestamp 
}
